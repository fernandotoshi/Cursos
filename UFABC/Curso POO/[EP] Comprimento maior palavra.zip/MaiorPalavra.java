import java.util.Scanner;

public class MaiorPalavra {
    public static int comprimento_maior_palavra(String texto) {
    	// Escreva o código do método aqui
    	
    }
    
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
		
        String texto = leitor.nextLine();
        
        System.out.println(comprimento_maior_palavra(texto));
    }
}