import java.util.Scanner;

public class VerificaNumero {
    public static boolean verifica_numero(int num) {
    	// Preencher método aqui
    }
    
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        
        int n = leitor.nextInt();
        
        if (verifica_numero(n))
            System.out.println("SIM");
        else
            System.out.println("NAO");
    }
}